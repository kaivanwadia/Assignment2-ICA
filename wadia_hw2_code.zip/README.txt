hw2main.m - A Matlab script to perform IC. Various parameters can be changed to test different scenarios. One can also specify multiple values of a parameter
	in an array and run multiple iterations with varying values for that parameter as described in the comments in the file.

PerformICA.m - The Matlab function that actually performs the ICA algorithm. Various parameters can be passed to the function for different kind of conditions 
	such as whether to check for convergence or not, use a random A matrix etc.

GetSignals.m - A Matlab function to select the specific signals for testing out of all the signals and also the specific timespan if mentioned.

PlotSignals.m - A Matlab function to Plot the signals and their amplitutdes over time.

To run the code one needs to simply run the hw2main.m

The variables are pretty self explanatory and can be changed to get different results.
